// square.cpp 
// Definitionsfil till klassen Square

#include <iostream>
#include "square.h"
// Eventuella ytterligare #include's läggs här

using namespace std;

// Default konstruktor
Square::Square()
{
	xpos = 0; 
	ypos = 0;
	sideLength = 0;
}

// Konstruktor för initiering av datamedlemmarna
Square::Square(int ixpos, int iypos, int isideLength)
{
	xpos = ixpos; 
	ypos = iypos;
	sideLength = isideLength;
}

// Dekonstruktor
Square::~Square()
{
	cout << "Nu körs dekonstruktor för square med xpos: " << xpos 
					<< " och ypos: " << ypos << endl;
}

// getArea
// Returnerar kvadratens area
int Square::getArea() const
{
	return sideLength*sideLength;
}

// setSideLength
// Datamedlemmen sideLength ges värdet slen
void Square::setSideLength(int slen)
{
	sideLength = slen;
}

// setXPos
// Datamedlemmen xpos ges värdet x
void Square::setXPos(int x)
{
    xpos = x;
}


// setYPos
// Datamedlemmen ypos ges värdet y
void Square::setYPos(int y) 
{
    ypos = y;
}

// getSideLength
// Returnerar datamedlemmen sideLength
int Square::getSideLength() const
{
    return sideLength;
}

// getXPos
// Returnerar datamedlemmen xpos
int Square::getXPos() const
{
    return xpos;
}

// getYPos
// Returnerar datamedlemmen ypos
int Square::getYPos() const 
{
    return ypos;
}
