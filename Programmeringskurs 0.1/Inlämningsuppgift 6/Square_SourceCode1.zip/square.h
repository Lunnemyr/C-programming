// square.h 
// Headerfil till klassen Square

#ifndef squareH
#define squareH
// Eventuella #include's läggs här

using namespace std;

// Klassdefinition
class Square
{
	private:
		int xpos;    // Datamedlemmar
		int ypos;
		int sideLength;

	public:
		Square();    // Default konstruktor
		// Konstruktor med parametrar
		Square(int ixpos, int iypos, int isideLength);     
		~Square();    // Dekonstruktor
    
		int getArea() const;    // Medlemsfunktioner
		// Medlemsfunktioner som sätter värden på datamedlemmarna
		void setSideLength(int length); 
		void setXPos(int x);
		void setYPos(int y);
		// Medlemsfunktioner som returnerar datamedlemmars värden
		int getSideLength() const;	
		int getXPos() const;
		int getYPos() const;

};    // Avslutar definitionen av klassen Square

#endif
