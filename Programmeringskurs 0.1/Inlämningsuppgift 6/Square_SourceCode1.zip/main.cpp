// Exempel på hur man delar upp klasser i headerfil och definitionsfil och 
// sedan anropar headerfilen från sitt huvudprogram.
// Klassdefinitionen av Square ligger i filen square.h
// Definitionerna av medlemsfunktionerna i Square ligger i filen square.cpp 

#include <iostream>
#include <iomanip>
#include "square.h"
// Eventuella ytterligare #include's läggs här 

using namespace std;

// Huvudprogram
int main()
{

	// Skapar ett objekt square1 av klassen Square, 
	// konstruktorn med parametrar körs.
	Square square1(5, 10, 4);

	// Sätter nytt värde på kvadratens sidlängd till 20
	square1.setSideLength(20);

	// Beräkna kvadratens area
	int sqArea = square1.getArea();

	// Skriv ut kvadratens area
	cout << "Square Area: " << sqArea << endl; 
	
	return 0;
}
