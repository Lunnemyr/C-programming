//Inl�mningsuppgift 6
//Henrik Axelsson, 750328-4999

//Metoderna �teranv�nda direkt fr�n tidigare projekt, inklippta och ej omskrivna i C++.


#include "menu.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include "heltals_klass.h"
#include "array_av_heltal.h"

using namespace std;

menu::menu()
{
    //ctor
}

menu::~menu()
{
    //dtor
}

//function show_menu
void menu::show_menu()
{
    printf("\n\n*****  MENY  *****\n\n");
    printf("   1. Skapa en array med default storlek, skriv ut\n");
    printf("\n   2. Skapa en array med egendefinierad storlek, skriv ut\n");
    printf("\n   3. Skapa en array med variabel storlek och fyll med slumptal, skriv ut\n");
    printf("\n   4. Skapa en array med variabel storlek och fyll med slumptal,\n      sortera den i stigande ordning samt skriv ut.\n");
    printf("\n   5. Avsluta\n\n");
    printf("Ange ett alternativ 1-5: ");
}
//END show menu


//function run_selection
void menu::run_selection(int selection)
{
   printf("\n\n");
   switch(selection){ //f�r att starta "r�tt" menyval enligt anv�ndarens inmatning

   case 1 :
      cout << "Du valde menyalternativ nr 1." << endl << endl;
      run_menyval_1();
      break;

   case 2 :
       cout << "Du valde menyalternativ nr 2." << endl << endl;
       run_menyval_2();
       break;

   case 3 :
       cout << "Du valde menyalternativ nr 3." << endl << endl;
       run_menyval_3();
       break;

   case 4 :
       cout << "Du valde menyalternativ nr 4." << endl << endl;
       run_menyval_4();
       break;

   case 5 :
       printf("Avsluta\n\n");
       exit(0); //avbryt programmet om anv�ndaren v�ljer 5
       break;
   }
}
//end run_selection

void menu::run_menyval_1()
{
    array_av_heltal * en_test_array_av_heltal;          //Pekare till ett array-objekt
    en_test_array_av_heltal = new array_av_heltal();    //Skapar dynamiskt med default storlek

    cout << "Arrayen blev (intierad till nollor):" << endl;  //Detta g�rs default i konstruktorn
    en_test_array_av_heltal->array_print();                  //Skriv ut arrayen

    delete en_test_array_av_heltal;
}

void menu::run_menyval_2()
{
    int storlek;
    cout << "\nVilken storlek vill du ha p� arrayen? Skriv ett tal: ";
    cin >> storlek;
    cout << endl;

    array_av_heltal * en_test_array_av_heltal;
    en_test_array_av_heltal = new array_av_heltal(storlek);

    cout << "\nArrayen blev (intierad till nollor):" << endl;
    en_test_array_av_heltal->array_print();

}

void menu::run_menyval_3()
{
    int storlek;
    cout << "\nVilken storlek vill du ha p� arrayen? Skriv ett tal: ";
    cin >> storlek;
    cout << endl;

    array_av_heltal * en_test_array_av_heltal;
    en_test_array_av_heltal = new array_av_heltal(storlek);

    int min_rnd;
    int max_rnd;

    cout << "Skriv in ett minsta tal f�r slumptalsgenereringen (OBS: tal >= 0): ";
    cin >> min_rnd;
    cout << endl;

    cout << "Skriv in ett st�rsta tal f�r slumptalsgenereringen: ";
    cin >> max_rnd;
    cout << endl;

    en_test_array_av_heltal->array_rnd_create(min_rnd, max_rnd);

    //Skriv ut f�re sortering
    cout << "Arrayen osorterad med slumptal:" << endl;
    en_test_array_av_heltal->array_print();
}

void menu::run_menyval_4()
{
    int storlek;
    cout << "\nVilken storlek vill du ha p� arrayen? Skriv ett tal: ";
    cin >> storlek;
    cout << endl;

    array_av_heltal * en_test_array_av_heltal;
    en_test_array_av_heltal = new array_av_heltal(storlek);

    int min_rnd;
    int max_rnd;

    cout << "Skriv in ett minsta tal f�r slumptalsgenereringen (OBS: tal >= 0): ";
    cin >> min_rnd;
    cout << endl;

    cout << "Skriv in ett st�rsta tal f�r slumptalsgenereringen: ";
    cin >> max_rnd;
    cout << endl;

    en_test_array_av_heltal->array_rnd_create(min_rnd, max_rnd);

    //Skriv ut f�re sortering
    cout << "Arrayen osorterad med slumptal:" << endl;
    en_test_array_av_heltal->array_print();

    //Sortera
    en_test_array_av_heltal->sortera_array();

    cout << "\nArrayen sorterad:" << endl;
    en_test_array_av_heltal->array_print();
    cout << endl;

    delete en_test_array_av_heltal;
}

//Hj�lpfunktioner


//function get_selection
int menu::get_selection()
{
   int valt_tal;

do {
    scanf("%d", &valt_tal); //l�s in menyvalet
    if (valt_tal < 1 || valt_tal >5) {
    printf("Fel, talet skall vara mellan 1 och 5! \n\n"); //kolla om talet �r mellan 1 & 4
    show_menu(); //om inte - visa menyn igen tills anv�ndare v�ljer "r�tt"
    }
}while(valt_tal < 1 || valt_tal >5);
return valt_tal; //skicka tillbaks det anv�ndaren valt
}
//end get_selection

// function pause
int menu::pause()
{
    int c;
    printf("\n\nTryck enter f�r att forts�tta!");
    //T�mmer inmatningsstr�mmen
    while((c=getchar()) != '\n' && c !=EOF);
    getchar();
    return 1;
}
//end pause

